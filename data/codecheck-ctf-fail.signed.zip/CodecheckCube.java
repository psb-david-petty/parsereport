/*
 * CodecheckCube.java
 *
 * Test of Codecheck.it and its structure using simple square and cube methods.
 *
 * @author Clarence T. Fishburn <clarence.fishburn@gmail.com>
 */

class CodecheckCube
{
    public static int cube(int n)
    {
         return n * n;   // STUB
    }
}