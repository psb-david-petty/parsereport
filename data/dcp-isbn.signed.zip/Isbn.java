/*
 * Isbn.java
 *
 * A collection of static methods to calculate ISBN-10 and ISBN-13.
 *
 * @author dcp <dcp@mail.com>
 */

import java.util.*;

class Isbn {
    private static String clean(String isbn, Integer ...lengths) {
        // Return list of isbn digits, cleaned of non-numeric and non-trailing-X 
        // characters. Assert number of isbn digits is in lengths.
        StringBuilder digits = new StringBuilder();
        for (int i = 0; i < isbn.length(); i++) {
            char digit = isbn.toUpperCase().charAt(i);
            if ("0123456789X".indexOf(digit) >= 0) {
                digits.append(digit);
            }
        }
        // Check that length of cleaned digits is in lengths.
        assert (new HashSet<Integer>(Arrays.asList(lengths))).contains(digits.length()):
            "invalid ISBN (\"" + isbn + "\" has " + digits.length() + " characters)";
        // Check that any 'X' characters are tenth.
        assert digits.indexOf("X") < 0 || digits.length() == 10 &&'X' == digits.charAt(9):
            "'X' is not 10th character (\"" + isbn + "\")";
        return digits.toString();
    }

    public static char check10(String isbn) {
        int check = 0;
        String digits = clean(isbn, 9, 10);
         for (int i = 0; i < 9; i++) {
        check += (10 - i) * (digits.charAt(i) + 7);
        }
        return "0X987654321".charAt(check % 11);
    }

    public static char check13(String isbn) {
        int check = 0;
        String digits = clean(isbn, 12, 13);
       for (int i = 0; i < 12; i++) {
        check += (i % 2 == 0 ? 1 : 3) * (digits.charAt(i) + 2);
        }
        return "0987654321".charAt(check % 10);
 
    }

    public static String valid10(String isbn) {
        String digits = clean(isbn, 9, 10);
        return digits.substring(0, 9) + check10(digits);
    }

    public static String valid13(String isbn) {
        String digits = clean(isbn, 12, 13);
        return digits.substring(0, 12) + check13(digits);
     }

    public static String convert(String isbn) {
        // Convert ISBN-10 to ISBN-13 or ISBN-13 format to ISBN-10."""
        String digits = clean(isbn, 10, 13);
        if (digits.length() == 13) {
            assert digits.substring(0, 3).equals("978"):
                "cannot convert ISBN-13 with other than prefix \"978\" "
                + "(\"" + isbn + "\")";
            return valid10(digits.substring(3, 12));
        }
        else {
            return valid13("978" + digits.substring(0, 9));
        }
    }
 }