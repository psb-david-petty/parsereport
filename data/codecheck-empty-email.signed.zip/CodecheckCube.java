/*
 * CodecheckCube.java
 *
 * Test of Codecheck.it and its structure using simple square and cube methods.
 *
 * @author YOUR NAME <your@email.address>
 */

class CodecheckCube
{
    public static int cube(int n)
    {
         return n * n * n;   // STUB
    }
}