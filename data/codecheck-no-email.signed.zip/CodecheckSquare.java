/*
 * CodecheckSquare.java
 *
 * Test of Codecheck.it and its structure using simple square and cube methods.
 *
 * @author YOUR NAME <your@email.address>
 */

class CodecheckSquare
{
    public static int square(int n)
    {
         return n * n;   // STUB
    }
}